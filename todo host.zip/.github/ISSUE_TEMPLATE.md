<GitHub issues are ONLY for BUG reports and FEATURE requests>
<Questions or support can be send to StackOverflow>
<PLEASE DO FOLLOW and fill the issue template below. Don't skip or remove any section>

## Issue Overview
<Please explain the issue overview here, short but concise and to-the-point>

## Issue Description
<Please explain the issue in details>

## Reproducables
<Please explain the way to reproduce your issue, or even better with Plunker link>

## Information
|                      	|                                 	|
|---------------------	|---------------------------------	|
| **Operating System** 	| Windows/OSX/Ubuntu/orYourOSHere 	|
| **Node version**     	| 4.x/5.x/orYourNodeVersionHere   	|
| **NPM Version**      	| 2.x/3.x/orYourNPMVersionHere    	|
| **Environment**       | Browser/Mobile/WebWorker          |
