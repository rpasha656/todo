import { Routes } from '@angular/router';

import { TodolistComponent } from './todolist.component';

export const TodolistRoutes: Routes = [
  { path: '', component: TodolistComponent }
];
