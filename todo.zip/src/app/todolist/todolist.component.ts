import { Component, Inject } from '@angular/core';
import { Todo } from './todo.model';
import { Title, PubSubServiceContract } from 'microui-contracts';
import { FileMetadata } from './filemetadata.model';
import './todolist.html';
@Component({
    moduleId: module.id,
    selector: 'as-todolist',
    template: require('./todolist.html')
})
export class TodolistComponent {
    public todo: Todo;
    public expDate: String;
    public date: Date;
    public list: Todo[];
    public showCompleted: Boolean;
    public fileMetadata: FileMetadata;
    constructor(private pubsub: PubSubServiceContract, @Inject(Title) public title: string) {
        this.showCompleted = true;
        this.todo = new Todo('Add me to list!', false);
        this.fileMetadata = new FileMetadata(new Date(), 0, 0, new Date(), 0, ' ', ' ', new Date(), 1, 1);
        this.list = [
            new Todo('Its cool'),
            new Todo('Hello', true)
        ];
    }
    ngOnInit() {
        this.date = new Date();
        this.date.setFullYear(this.date.getFullYear() + 1);
        this.expDate = this.date.toLocaleDateString();
    }
    addTodo() {
        let todo = Todo.clone(this.todo);
        this.list = this.list.concat(todo);
        this.todo.clear();
        this.pubsub.publish('Todo', {
            action: 'added',
            value: todo
        });
    }

    delTodo(todoIndex: number) {
        this.list = this.list.filter((todo, index) => index !== todoIndex);
        this.pubsub.publish('Todo', {
            action: 'deleted',
            value: todoIndex
        });
    }

    addFileMetaData() {
        let fileMetadate = FileMetadata.clone(this.fileMetadata);
        this.pubsub.addFileMetaDate(fileMetadate);
    };
}
