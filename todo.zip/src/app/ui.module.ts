import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TodolistRoutes, TodolistModule } from './todolist/index';

@NgModule({
    declarations: [
    ],
    imports: [
        TodolistModule,

        RouterModule.forChild(TodolistRoutes)

    ],
    providers: []
})
export class UiModule {
}
