export class FileMetadata {
    constructor(
        public accessedOn: Date,
        public documentgroupId: number,
        public documentnameId: number,
        public expirationdate: Date,
        public fileextensionId: number,
        public filename: string,
        public planname: string,
        public publicationdate: Date,
        public sposid: number,
        public statusid: number
    ) { }
}